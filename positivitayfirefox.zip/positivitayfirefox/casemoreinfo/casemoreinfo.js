$("#showReopenOption-announce").click();
    setTimeout(function() {
	$("#replyCase-announce").click();
    },500);

    setTimeout(function() {
	$("#emailMessage").text("Greetings,\n\nCould we receive an update regarding this case.\n\nThank You");
    },1000);
