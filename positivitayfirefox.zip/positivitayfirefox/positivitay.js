$("#detailpage").click(function(){
	var positivitayasin = $("#dopages").val();
	if(positivitayasin == ''){

	}
	else{
	console.log(positivitayasin);
	window.open('https://amazon.com/dp/'+positivitayasin, '_blank');
	}
});

$("#offerpage").click(function(){
	var positivitayasin = $("#dopages").val();
	if(positivitayasin == ''){

	}
	else{
	console.log(positivitayasin);
	window.open('https://amazon.com/gp/offer-listing/'+positivitayasin, '_blank');
	}
});

$("#casepage").click(function(){
	var positivitayasin = $("#dopages").val();
	if(positivitayasin == ''){

	}
	else{
	console.log(positivitayasin);
	window.open('https://sellercentral.amazon.com/cu/case-dashboard/view-case?caseID='+positivitayasin, '_blank');
	}
});

$("#casesmenu").click(function(){
	$(".options").hide();
	$("#casemoreinfo").show();
});

function casemoreinfo() {
  browser.tabs.executeScript({
    file: 'casemoreinfo/casemoreinfo.js'
  });
}

document.getElementById('casemoreinfo').addEventListener('click', casemoreinfo);
