$(document).ready(function(){
$("body").one("click",function(){
$("._3_hHr3kfEhbNYRFM5YJxH9").remove();
});
});
